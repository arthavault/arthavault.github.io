ARTHAVAULT website (static: index.html = home, download/index.html = Download Center).
ADD A NEW VERSION: 1) put the APK in downloads/  2) add a new block at the TOP of versions.json (version, name, date, size in bytes, notes, minAndroid, url, sha256, signingKey, status "Latest")  3) change the old Latest block's status to "Previous".
Size: ls -l or stat -c%s file.apk. Hash: sha256sum file.apk. Nothing else needs editing.
