ARTHAVAULT website (static). Upload the whole folder to GitHub Pages, Netlify or any web host.
index.html = the page, downloads/ = all APK versions, versions.json = version list.
To add a new version: copy the APK into downloads/, add it at the top of versions.json, and update the V array near the end of index.html (sha256sum gives the hash).
